import tweepy
import openai
import random

api_key = "soeNzbVe9oBKodAIkBq4d73SK"
api_secret = "ql3CudnjhnZF9tg0YY7xi3dEDWZIncfEa7gMOELdxtx58p89cL"
access_key = "1517032150964391936-IcOnXTfh7aghHy2vseYbJPGvFnO6Q0"
access_secret = "ehjHY1Meycq57ImeKEJG3vLrPUVxGUc5P1fkTTDS2zLHi"

auth = tweepy.OAuthHandler (api_key, api_secret)
auth.set_access_token(access_key, access_secret)
api = tweepy.API(auth)

openai.api_key = "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"


prompts = [
        {
            "hashtag": "#meme",
            "text": "post a meme on engineer"
        },
        {
            "hashtag": "#technology",
            "text": "tweet something cool for #technology"
        },
        {
            "hashtag": "#India",
            "text": "tweet something cool for India"
        },
        {
            "hashtag": "Coding",
            "text": "tweet something cool for coding"
        },
        {
            "hashtag": "#Music",
            "text": "tweet something cool about Music"
        },
        {
            "hashtag": "#Nature",
            "text": "tweet something about Nature"
        },
        {
            "hashtag": "#ShareMarket",
            "text": "Tweet facts about nifty"
        },
        {
            "hashtag": "weather",
            "text": "what's the weather today in delhi"
        },
        {
            "hashtag": "#joke",
            "text": "tell me a joke"
        },
    ]

chosen_prompt = random.choice(prompts)
text_openai = chosen_prompt["text"]

response = openai.Completion.create(
    engine="text-davinci-001",
    prompt=text_openai,
    max_tokens=256,
    )

text = response.choices[0].text
print(text)

api.update_status(text)